import Search from "./models/Search";
import Recipe from "./models/Recipe";
import List from "./models/Lists";
import Likes from "./models/Likes";
import * as searchView from "./views/searchView";
import * as recipeView from "./views/recipeView";
import * as listView from "./views/listView";
import * as likesView from "./views/likesView";
import { elements, renderLoader, clearLoader } from "./views/base";

/* Global state of the app
- Search object
- Current recipe object
- Shopping list object
- Liked recipes
 */
const state = {};

/**
 * search controller
 */
const constrolSearch = async () => {
    // 1) Get query from the view
    const query = searchView.getInput();
    //const query = 'pizza';

    if (query) {
        // 2) New search object adn add to state
        state.search = new Search(query);

        // 3) Prepare UI for results
        searchView.clearInput();
        searchView.clearResults();
        renderLoader(elements.searchRes);

        try {
            // 4) Search for recipes
            await state.search.getResults();
            // 5) Render results on UI
            clearLoader();
            searchView.renderResults(state.search.result);
        } catch (error) {
            alert("Somthing with wrong with the search");
            clearLoader();
        }
    }
};

elements.searchForm.addEventListener("submit", e => {
    // It prevents a submit button from submitting a form.
    e.preventDefault();
    constrolSearch();
});

// window.addEventListener("load", e => {
//     e.preventDefault();
//     constrolSearch();
// });

elements.searchResPages.addEventListener("click", e => {
    const btn = e.target.closest(".btn-inline");
    if (btn) {
        const goToPage = parseInt(btn.dataset.gopage, 10);
        searchView.clearResults();
        searchView.renderResults(state.search.result, goToPage);
    }
});

/**
 * Recipe Controller
 */
const controlRecipe = async () => {
    //Get ID from url
    const id = window.location.hash.replace("#", "");

    if (id) {
        // Prepare UI for changes
        recipeView.clearRecipe();
        renderLoader(elements.recipe);

        // If there is search result
        if (state.search) {
            // Find the index of the recipe in the result list
            const index = state.search.result.findIndex(
                el => el.recipe_id === id
            );

            // If found
            if (index !== -1) {
                // Clear current result page
                searchView.clearResults();

                // Go to the page where the recipe is located
                searchView.renderResults(
                    state.search.result,
                    Math.ceil((index + 1) / 10)
                );

                // Highlight the selected recipe
                searchView.highlightSelected(id);
            }
        }

        // Create new Recipe Object
        state.recipe = new Recipe(id);

        console.log(state.recipe);
        //testing
        //window.r = state.recipe;

        try {
            // Get Recipe data and parse ingredients
            await state.recipe.getRecipe();
            //console.log(state.recipe.ingredients);
            // uniform ingredients
            state.recipe.parseIngredients();

            // Calculate servings and time
            state.recipe.calcTime();
            state.recipe.calcServings();

            // Render recipe
            clearLoader();
            recipeView.renderRecipe(state.recipe, state.likes.isLiked(id));
        } catch (error) {
            console.log(error);
            alert("Error processing recipe!");
        }
    }
};

// window.addEventListener('hashchange', controlRecipe);
// window.addEventListener('load', controlRecipe);

["hashchange", "load"].forEach(event =>
    window.addEventListener(event, controlRecipe)
);

/**
 * LIST CONTROLLER
 */
const controlList = () => {
    // Create a new List if none
    if (!state.list) state.list = new List();

    // Add each ingredient to List
    state.recipe.ingredients.forEach(el => {
        // Check if the ingredient already exists
        const index = state.list.items.findIndex(
            item => item.ingredient === el.ingredient
        );
        // if not exists
        if (index === -1) {
            const newItem = state.list.addItem(
                el.count,
                el.unit,
                el.ingredient
            );
            listView.renderItem(newItem);
            // if exists
        } else {
            // just add count
            state.list.updateCountByIndex(index, el.count);
            // Update shopping list
            listView.updateList(state.list.items[index]);
        }
        listView.toggleRemoveBtn(state.list.getNumItems());
    });
};

// Handle delete and update list item events
elements.shopping.addEventListener("click", e => {
    const id = e.target.closest(".shopping__item").dataset.itemid;

    // Handle the delete button
    if (e.target.matches(".shopping__delete, .shopping__delete *")) {
        // Delete from state
        state.list.deleteItem(id);

        // Delete from UI
        listView.deleteItem(id);
        listView.toggleRemoveBtn(state.list.getNumItems());
    } else if (e.target.matches(".shopping__count-value")) {
        const val = parseFloat(e.target.value, 10);
        state.list.updateCountByID(id, val);
    }
});

// Delete All shopping list items
elements.removeBtn.addEventListener("click", e => {
    state.list.deleteAll();
    listView.deleteAll();
    listView.toggleRemoveBtn(state.list.getNumItems());
});

/**
 * LIKE CONTROLLER
 */

const controlLike = () => {
    if (!state.likes) state.likes = new Likes();
    const currentID = state.recipe.id;

    // User has Not yet liked the recipe
    if (!state.likes.isLiked(currentID)) {
        // Add like to the state
        const newLike = state.likes.addLike(
            currentID,
            state.recipe.title,
            state.recipe.author,
            state.recipe.img
        );

        // Toggle the like button
        likesView.toggleLikeBtn(true);

        // Add like to UI list
        likesView.renderLike(newLike);

        // User Has liked the recipe
    } else {
        // Remove like from the state
        state.likes.deleteLike(currentID);
        // Toggle the like button
        likesView.toggleLikeBtn(false);
        // Remove like to UI list
        likesView.deleteLike(currentID);
    }
    likesView.toggleLikeMenu(state.likes.getNumLikes());
};

// Handling recipe button clicks
elements.recipe.addEventListener("click", e => {
    if (e.target.matches(".btn-decrease, .btn-decrease *")) {
        if (state.recipe.servings > 1) state.recipe.updateServings("dec");
        recipeView.updateServingsIngredients(state.recipe);
    } else if (e.target.matches(".btn-increase, .btn-increase *")) {
        state.recipe.updateServings("inc");
        recipeView.updateServingsIngredients(state.recipe);
    } else if (e.target.matches(".recipe__btn--add, .recipe__btn--add *")) {
        controlList();
    } else if (e.target.matches(".recipe__love, .recipe__love *")) {
        controlLike();
    }
});

// Restore liked recipes and shopping list on page load
window.addEventListener("load", () => {
    state.likes = new Likes();
    state.list = new List();

    // Restore likes
    state.likes.readStorage();
    state.list.readStorage();

    // Toggle like menu button
    likesView.toggleLikeMenu(state.likes.getNumLikes());
    listView.toggleRemoveBtn(state.list.getNumItems());

    // Render the existing likes and shopping lists
    state.likes.likes.forEach(like => likesView.renderLike(like));
    state.list.items.forEach(item => listView.renderItem(item));
});
