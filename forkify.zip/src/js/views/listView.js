import { elements, elementStrings } from "./base";

export const renderItem = item => {
    const markup = `
        <li class="shopping__item" data-itemid=${item.id}>
            <div class="shopping__count">
                <input type="number" value="${item.count}" step="${item.count}" class="shopping__count-value">
                <p>${item.unit}</p>
            </div>
            <p class="shopping__description">${item.ingredient}</p>
            <button class="shopping__delete btn-tiny">
                <svg>
                    <use href="img/icons.svg#icon-circle-with-cross"></use>
                </svg>
            </button>
        </li>  
    `;
    elements.shopping.insertAdjacentHTML('afterbegin', markup);
};

export const toggleRemoveBtn = numItems => {
    elements.removeBtn.style.visibility = numItems > 0 ? "visible" : "hidden";
};

export const deleteItem = id => {
    document.querySelectorAll('shopping__item')
    const item = document.querySelector(`[data-itemid="${id}"]`);
    if (item)  item.parentElement.removeChild(item);
};

export const deleteAll = () => {
    elements.shopping.innerHTML = "";
};

export const updateList = item => {
    const child = document.querySelector(`[data-itemid="${item.id}"]`);
    if (child) {
        child.childNodes[1].childNodes[1].value = item.count;
    }
};